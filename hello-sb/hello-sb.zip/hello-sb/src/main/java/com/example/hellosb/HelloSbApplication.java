package com.example.hellosb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloSbApplication.class, args);
	}

}
